/**
 * 
 */
/**
 * 
 */
module customer_and_item {
}